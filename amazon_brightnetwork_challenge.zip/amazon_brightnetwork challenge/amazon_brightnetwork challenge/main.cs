﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bright_network_amazon_challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            mapdata run = new mapdata();



            run.run();
        }
    }
}
