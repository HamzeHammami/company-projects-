﻿using System;
using System.Linq;


namespace bright_network_amazon_challenge
{
    internal class mapdata
    {

        public void run()
        {
            Random rnd = new Random();
            int[] map_obst = { 97, 87, 67, 68 }; // obstcale array 
            int robot_x_pos = 0; // rnd.Next(0, 9); //robot x postion 
            int robot_y_pos = 0; // rnd.Next(0, 9); //robot y postion 
            int robot_pos = (robot_x_pos * 10) + robot_y_pos; // robot postion in intger 
            int robot_x_goal = 9;// rnd.Next(0, 9); // robot x goal
            int robot_y_goal = 9;// rnd.Next(0, 9); // robot y goal 
            int robot_goal = (robot_x_goal * 10) + robot_y_goal; // robot goal in intger 
            int obst_new = 15; // amount of new obstcales wanted 
            string obstcale = null; // last obscale before failing 
            int steps = 50;

            for (int i = 0; i < obst_new;) // for loop to add new obstcales 
            {
                int obstx = rnd.Next(0, 9); // random x 
                int obsty = rnd.Next(0, 9); // arndom y
                int obst = (obstx * 10) + obsty; // turn into int

                if (obst == robot_pos || obst == robot_goal || map_obst.Contains(obst)) // check if obst alreatd exist or = to starting or goal postion 
                {
                    i = i;
                }
                else
                {
                    map_obst = map_obst.Append(obst).ToArray(); // add new obstcale to array 
                    i++;
                }
            }

            Console.WriteLine("\nstaring postion: [" + robot_x_pos + ", " + robot_y_pos + "]"); // print starting
            Console.WriteLine("\ndelivery goal: [" + robot_x_goal + ", " + robot_y_goal + "]");// print goal
            Console.WriteLine("\nintger obstcales:"); // obstcales in intger 
            foreach (var grid in map_obst)
            {
                Console.Write(grid + "   "); // print obstcales 
            }
            Console.WriteLine("\nintger values examples: 61 = [6,1], 5 = [0,5] "); // intger example to meaning 
            Console.WriteLine("\npress enter to proceed with simulation"); // user press enter 
            Console.ReadLine(); // read line to delay operation 
            bool goal_reached = false;  // goal not reached 
            int x = 0; // steps int 
            Console.WriteLine("\nstep " + x + ": [" + robot_x_pos + "," + robot_y_pos + "]"); // step 0 or staritng postion
            while (goal_reached == false) // if goal is not reached while loop 
            {
                if ((robot_x_pos * 10) + robot_y_pos == robot_goal) // check if goal was met 
                {
                    Console.WriteLine("robot deliver success " + x + " steps were taken"); // succues deiver 
                    goal_reached = true; // end loop 
                }

                if (x >= 51)
                {
                    Console.WriteLine("delivery failed due to too many steps or complete path block, try removing obstcales"); // too many obstcales detcted 
                    goal_reached = true; // end delivery 
                }

                while (robot_x_goal > robot_x_pos & x < 51)  // if x goal was not met 
                {
                    int next1 = ((robot_x_pos + 1) * 10) + (robot_y_pos);
                    while (map_obst.Contains(next1) & x < 51 || robot_x_pos + 1 > 9 & x < 51) // check next x postion 
                    {
                        int next2 = ((robot_x_pos) * 10) + (robot_y_pos + 1);
                        while (map_obst.Contains(next2) & x < 51 || robot_y_pos + 1 > 9 & x < 51)// check next y postion 
                        {
                            int next3 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                            while (map_obst.Contains(next3) & x < 51 || robot_x_pos - 1 < 0 & x < 51) // check next -x postion  
                            {
                                int next4 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                                while (map_obst.Contains(next4) & x < 51 || robot_y_pos - 1 < 0 & x < 51 || x == 50) // check next -y postion 
                                {
                                    if (x == steps) // to many steps break
                                    {
                                        break;
                                    }
                                    // else obstcale blocking 
                                    obstcale = ("[" + robot_x_pos + ", " + (robot_y_pos + 1) + "]");
                                    Console.WriteLine("Robot could not find a path too many obstcales, try removing the following obstcale:" + obstcale);
                                    x = 51;
                                    break; ;

                                }
                                next4 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                                if (x > 50 || map_obst.Contains(next4) & x < 51 || robot_y_pos - 1 < 0 & x < 51) // second obstcale check
                                {
                                    break;
                                }
                                next3 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                                robot_y_pos -= 1; // move
                                x += 1;
                                Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                                System.Threading.Thread.Sleep(500);

                            }
                            next3 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                            if (x > steps || map_obst.Contains(next3) & x < 51 || robot_x_pos - 1 < 0 & x < 51) // second obstcale check
                            {
                                break;
                            }

                            next2 = ((robot_x_pos) * 10) + (robot_y_pos + 1);
                                robot_x_pos -= 1; // move 
                                x += 1;
                                Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                                System.Threading.Thread.Sleep(500);


                            }
                            next2 = ((robot_x_pos) * 10) + (robot_y_pos + 1);
                            if (x > 50 || map_obst.Contains(next2) & x < 51 || robot_y_pos + 1 > 9 & x < 51) // second obstcale check
                            {
                                break;
                            }
                            next1 = ((robot_x_pos + 1) * 10) + (robot_y_pos);
                            robot_y_pos += 1; // move 
                            x += 1;
                            Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                            System.Threading.Thread.Sleep(500);

                        }
                        next1 = ((robot_x_pos + 1) * 10) + (robot_y_pos);
                        if (x > steps || map_obst.Contains(next1) & x < 51 || robot_x_pos + 1 > 9 & x < 51) // second obstcale check
                        {
                            break;
                        }
                        robot_x_pos += 1; //move 
                        x += 1;
                        Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                        System.Threading.Thread.Sleep(500);
                    }
                    while (robot_y_goal > robot_y_pos & x < 51) //same as x loop but we prportise 1 Y, 2 -X, 3 -Y, X
                    {
                        int next1 = ((robot_x_pos) * 10) + (robot_y_pos + 1);
                        while (map_obst.Contains(next1) & x < steps || robot_y_pos + 1 > 9 & x < steps)
                    {
                            int next2 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                            while (map_obst.Contains(next2) & x < steps || robot_x_pos - 1 < 0 & x < steps)
                        {
                                int next3 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                                while (map_obst.Contains(next3) & x < steps || robot_y_pos - 1 < 0 & x < steps)
                            {
                                    int next4 = ((robot_x_pos + 1) * 10) + (robot_y_pos);
                                    while (map_obst.Contains(next4) & x < steps || robot_x_pos + 1 > 9 & x < steps || x == steps)
                                {
                                        if (x == steps)
                                    {
                                            break;
                                        }
                                        obstcale = ("[" + (robot_x_pos + 1) + ", " + (robot_y_pos) + "]");
                                        Console.WriteLine("Robot could not find a path too many obstcales, try removing the following obstcale:" + obstcale);
                                        x = 51;
                                        break;

                                    }
                                    next1 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                                    if (x > steps || map_obst.Contains(next1) & x < steps || robot_x_pos + 1 > 9 & x < steps)
                                {
                                        break;
                                    }
                                    next3 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                                    robot_x_pos += 1;
                                    x += 1;
                                    Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                                    System.Threading.Thread.Sleep(500);

                                }
                                next2 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                                if (x > steps || map_obst.Contains(next2) & x < steps || robot_y_pos - 1 < 0 & x < steps)
                            {
                                    break;
                                }
                                next2 = ((robot_x_pos - 1) * 10) + (robot_y_pos);
                                robot_y_pos -= 1;
                                x += 1;
                                Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                                System.Threading.Thread.Sleep(500);


                            }
                            int next5 = ((robot_x_pos) * 10) + (robot_y_pos - 1);
                            if (x > steps || map_obst.Contains(next5) & x < steps || robot_x_pos - 1 < 0 & x < steps)
                        {
                                break;
                            }
                            next1 = ((robot_x_pos) * 10) + (robot_y_pos + 1);
                            robot_x_pos -= 1;
                            x += 1;
                            Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                            System.Threading.Thread.Sleep(500);

                        }
                        int next6 = ((robot_x_pos + 1) * 10) + (robot_y_pos);
                        if (x > steps || map_obst.Contains(next6) & x < steps || robot_y_pos + 1 > 9 & x < steps)
                    {
                            break;
                        }
                        robot_y_pos += 1;
                        x += 1;
                        Console.WriteLine("step " + x + ": [" + robot_x_pos + ", " + robot_y_pos + "] ");
                        System.Threading.Thread.Sleep(500);
                    }

                }
            }
        }
    }

